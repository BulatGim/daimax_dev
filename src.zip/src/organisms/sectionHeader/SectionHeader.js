import './SectionHeader.css'
export default function SectionHeader(props){
    function createMarkup() {
        return {__html: props.MainTitle};
    }
    return (
        <section className="header" id="header">
            <div className="header__logo"></div>
            <div className="header__info">
                <h1 className="header__title" dangerouslySetInnerHTML={createMarkup()}></h1>
                <hr className="header__line"/>
                <p className="header__subtitle">Вы – ставите задачу, DAIMAX.team – выводит ваш бизнес в цифровое пространство вместе с громким именем, запоминающимся фирменным стилем и крутым шустрым сайтом. </p>
                <p className="header__subtitle">Готовы к успеху на рынке товаров и услуг?</p>
            </div>
        </section>
    )
}
